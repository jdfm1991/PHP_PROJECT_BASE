<?php
require_once("../../config/conexion.php");

class Incomes extends Conectar
{
  public function createDataIncomeDB($id, $income, $penalty, $detail, $percent, $mont, $montp)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("INSERT INTO income_data_table (id, datereg, incomeaccount, byreceipt, incomename, percent, amountpercent, incomeaumont) VALUES (:id, :date, :income, :penalty, :detail, :percent, :montp, :mont)");
    $stmt->execute(['id' => $id, 'date' => date('Y-m-d'), 'income' => $income, 'penalty' => $penalty, 'detail' => $detail, 'percent' => $percent, 'mont' => $mont, 'montp' => $montp]);
    return $stmt->rowCount();
  }
  /* FUNCION PARA EJECUTAR CONSULTAS SQL PARA TRAER INFORMACION DE LAS CUENTAS DE GASTOS EXISTENTES EN LA BASE DE DATOS */
  public function getListDataIncomeDB()
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("SELECT A.id, datereg, B.incomeaccount, incomename, amountpercent, incomeaumont 
                                  FROM income_data_table AS A 
                                  INNER JOIN income_accounts_data_table AS B ON A.incomeaccount=B.id
                                WHERE statusincome=1");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }
   /* FUNCION PARA EJECUTAR CONSULTAS SQL PARA TRAER INFORMACION UNA UNIDAD DEPARTAMENTAL EXISTENTE EN LA BASE DE DATOS */
  public function getDataIncomeDB($id)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("SELECT * FROM income_data_table WHERE id = :id");
    $stmt->execute(['id' => $id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }

  public function updateDataIncomeDB($id, $detail, $mont, $montp)
  {
    $conectar = parent::conexion();
    $stmt = $conectar->prepare("UPDATE income_data_table SET incomename=:income, amountpercent=:percent, incomeaumont=:aumont WHERE id = :id");
    $stmt->execute(['income' => $detail, 'percent' => $montp, 'aumont' => $mont, 'id' => $id]);
    return $stmt->rowCount();
  }

  public function validateAccountsRelatedIncomeDB($id)
  {
     $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("SELECT * FROM income_data_table WHERE incomeaccount = :account AND statusincome = 1");
    $stmt->execute(['account' => $id]);
    return $stmt->rowCount();
    
  }
  public function deleteDataIncomeDB($id)
  {
    $conectar = parent::conexion();
    $stmt = $conectar->prepare("UPDATE income_data_table SET statusincome = :status WHERE id = :id");
    $stmt->execute(['status' => 0, 'id' => $id]);
    return $stmt->rowCount();
  }

  public function getDataDetailsIncomeDB($id)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("SELECT id, incomename, incomeaccount, incomebalance 
                                  FROM income_data_table 
                                  WHERE incomeaccount=:id AND statusincome=1 AND byreceipt=0");
    $stmt->execute(['id' => $id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }
  public function getDataIncomeWithoutInterestDB($id)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("SELECT id, incomename, incomeaccount, incomebalance 
                                  FROM income_data_table 
                                  WHERE incomeaccount=:id AND statusincome=1 AND byreceipt=1 AND percent=0");
    $stmt->execute(['id' => $id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }

  public function getDataIncomeWithInterestDB($id)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("SELECT id, incomename, incomeaccount, amountpercent 
                                  FROM income_data_table 
                                  WHERE incomeaccount=:id AND statusincome=1 AND byreceipt=1 AND percent=1");
    $stmt->execute(['id' => $id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }

    public function createDataPenaltyReceiptsDB($receipt, $unit, $account, $income, $penalty, $amount)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("INSERT INTO income_penalty_data_table(datep, unit, receipt, account, income, namepenalty, amount, dateupt) VALUES (NOW(), :unit, :receipt, :account, :income, :penalty, :amount, NOW())");
    $stmt->execute(['unit' => $unit, 'receipt' => $receipt, 'account' => $account, 'income' => $income, 'penalty' => $penalty, 'amount' => $amount]);
    return $stmt->rowCount();
  }

  public function validatePenaltyReceiptDB($receipt, $account, $income)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("SELECT * FROM income_penalty_data_table WHERE receipt = :receipt AND account = :account AND income = :income AND status = 1 AND datep < NOW() and dateupt < NOW()");
    $stmt->execute(['receipt' => $receipt, 'account' => $account, 'income' => $income]);
    return $stmt->rowCount();
  }

  public function updateDataPenaltyReceiptsDB($receipt, $account, $income, $amount)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("UPDATE income_penalty_data_table SET amount = :amount, dateupt = NOW() WHERE receipt = :receipt AND account = :account AND income = :income");
    $stmt->execute(['amount' => $amount, 'receipt' => $receipt, 'account' => $account, 'income' => $income]);
    return $stmt->rowCount();
  }

  public function getDataPenaltiesByReceivableDB($receipt)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("SELECT namepenalty, amount FROM income_penalty_data_table WHERE receipt = :receipt");
    $stmt->execute(['receipt' => $receipt]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }

  public function updatePenaltiesReceiptByUnitDB($receipt)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("UPDATE income_penalty_data_table SET status = 0 WHERE receipt = :receipt AND datep < NOW()"); 
    $stmt->execute(['receipt' => $receipt]);
    return $stmt->rowCount();    
  }

  public function getPrevLateReceiptByUnitDB($unit)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("SELECT amount FROM income_penalty_data_table WHERE unit = :unit AND namepenalty LIKE '%MORA%' AND status = 1 ORDER BY datep DESC LIMIT 1");
    $stmt->execute(['unit' => $unit]);
    return $stmt->fetchColumn();
  }

  public function getPrevAdmExpReceiptByUnitDB($unit)
  {
    $conectar = parent::conexion();
    parent::set_names();
    $stmt = $conectar->prepare("SELECT amount FROM income_penalty_data_table WHERE unit = :unit AND namepenalty LIKE '%GASTOS ADMIN%' AND status = 1 ORDER BY datep DESC LIMIT 1");
    $stmt->execute(['unit' => $unit]);
    return $stmt->fetchColumn();
  }

}
