<?php
require_once(PATH_ASSETS . '/components/modal.php');
?>
<!-- Bootstrap core JavaScript-->
<script src="<?php echo  URL_ASSETS; ?>/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo  URL_ASSETS; ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo  URL_ASSETS; ?>/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo  URL_ASSETS; ?>/js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="<?php echo  URL_ASSETS; ?>/vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo  URL_ASSETS; ?>/js/demo/chart-area-demo.js"></script>
<script src="<?php echo  URL_ASSETS; ?>/js/demo/chart-pie-demo.js"></script>

<!-- File sweetalert2 -->
<script src="<?php echo  URL_ASSETS; ?>/js/sweetalert2.min.js"></script>

<!-- File Datatables -->
<script src="<?php echo  URL_ASSETS; ?>/js/datatables.min.js"></script>

<script src="<?php echo  URL_APP; ?>/index.js"></script>

